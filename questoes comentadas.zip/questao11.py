import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

# --- Definição do Problema de Programação Linear ---

# Coeficientes da função objetivo (para linprog, é para MINIMIZAR c.T @ x)
# Para maximizar 100x1 + 80x2 + 120x3 + 30x4, minimizamos -100x1 - 80x2 - 120x3 - 30x4
c = [-100, -80, -120, -30] # Coeficientes do lucro negativo

# Coeficientes das restrições de desigualdade (A_ub @ x <= b_ub)
# x1 + x2 + x3 + 4x4 <= 300 (Tábuas)
# 0x1 + x2 + x3 + 2x4 <= 600 (Pranchas)
# 3x1 + 2x2 + 4x3 + 0x4 <= 500 (Painéis)
A_ub = [
    [1, 1, 1, 4],   # Tábuas
    [0, 1, 1, 2],   # Pranchas
    [3, 2, 4, 0]    # Painéis
]
b_ub = [300, 600, 500] # Limites dos recursos

# Limites das variáveis (não negatividade)
# x1 >= 0, x2 >= 0, x3 >= 0, x4 >= 0
x_bounds = (0, None)
bounds = [x_bounds, x_bounds, x_bounds, x_bounds] # Para cada uma das 4 variáveis

# --- Execução da Otimização Linear ---
print("--- Otimização de Lucro da Fábrica de Móveis (Questão 11) ---")

result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')

# --- Extração e Exibição dos Resultados ---
if result.success:
    x1_opt, x2_opt, x3_opt, x4_opt = result.x
    
    # Calcular o lucro máximo (invertendo o sinal do resultado da minimização)
    max_lucro = -result.fun
    
    print(f"\n--- Resultado da Produção Ótima ---")
    print(f"Quantidades a fabricar para maximizar o lucro:")
    print(f"  Escrivaninhas (x1): {x1_opt:.2f} unidades")
    print(f"  Mesas (x2):         {x2_opt:.2f} unidades")
    print(f"  Armários (x3):      {x3_opt:.2f} unidades")
    print(f"  Prateleiras (x4):   {x4_opt:.2f} unidades")
    print(f"\nLucro máximo total: ${max_lucro:.2f}")

    # Verificar o uso dos recursos
    recursos_utilizados = np.dot(A_ub, result.x)
    print("\n--- Recursos Utilizados vs. Disponíveis ---")
    print(f"  Tábuas:       {recursos_utilizados[0]:.2f}m / {b_ub[0]}m")
    print(f"  Pranchas:     {recursos_utilizados[1]:.2f}m / {b_ub[1]}m")
    print(f"  Painéis:      {recursos_utilizados[2]:.2f}m / {b_ub[2]}m")

else:
    print(f"\nNão foi possível encontrar a solução ótima.")
    print(f"Status da otimização: {result.message}")

# --- Visualização ("Função Mesh" para PL - Plot 2D da Região Viável) ---
# Para um problema de PL com 4 variáveis, uma visualização 3D completa é impossível.
# A melhor representação de "mesh" em PL é um gráfico 2D da região viável
# se considerarmos 2 variáveis principais e fixarmos as outras ou projetarmos.
# No entanto, com 4 variáveis, um plot 2D das restrições de cada par de variáveis não é suficiente.
# O mais direto é mostrar o resultado numericamente.
# Se quisermos um plot, podemos fixar x3=0 e x4=0 para visualizar as restrições em x1 e x2.

print("\n--- Visualização da Região Viável (x3=0, x4=0 para ilustração 2D) ---")
x1_plot_vals = np.linspace(0, 200, 400) # Ajustado para cobrir o range relevante
x2_plot_vals = np.linspace(0, 300, 400)

plt.figure(figsize=(10, 8))

# Plotar as linhas das restrições
# 1. x1 + x2 <= 300 (Tábuas) => x2 = 300 - x1
plt.plot(x1_plot_vals, 300 - x1_plot_vals, label='Tábuas ($x_1 + x_2 \\leq 300$)')

# 2. x2 <= 600 (Pranchas) (para x3=0, x4=0, isso se torna apenas x2 <= 600)
plt.axhline(y=600, color='grey', linestyle='--', label='Pranchas ($x_2 \\leq 600$)')

# 3. 3x1 + 2x2 <= 500 (Painéis) => x2 = (500 - 3x1) / 2
plt.plot(x1_plot_vals, (500 - 3*x1_plot_vals) / 2, label='Painéis ($3x_1 + 2x_2 \\leq 500$)')

# Eixos de não-negatividade (já implícito nos limites do plot, mas útil para clareza)
plt.axvline(x=0, color='k', linestyle='-')
plt.axhline(y=0, color='k', linestyle='-')

# Plotar o ponto ótimo real (que pode não estar no plano x3=0, x4=0)
if result.success:
    # Apenas plota se x3_opt e x4_opt forem efetivamente zero
    if abs(x3_opt) < 1e-6 and abs(x4_opt) < 1e-6: # Usar um epsilon para comparação com zero
        plt.scatter(x1_opt, x2_opt, color='red', s=100, marker='o',
                    label=f'Ótimo Geral: $x_1$={x1_opt:.0f}, $x_2$={x2_opt:.0f}')
    else:
        print("\nNota: O ponto ótimo real não está neste plano 2D (x3=0, x4=0).")


plt.xlim(-5, 200) # Ajusta os limites para focar na região relevante
plt.ylim(-5, 300) # Ajusta os limites para focar na região relevante
plt.xlabel('Quantidade de Escrivaninhas ($x_1$)')
plt.ylabel('Quantidade de Mesas ($x_2$)')
plt.title('Região Viável das Restrições (x3=0, x4=0)')
plt.legend()
plt.grid(True)
# plt.show() # Para exibir o gráfico interativamente (se configurado)
plt.savefig('questao11_regiao_viável.png') # Para salvar o gráfico como imagem