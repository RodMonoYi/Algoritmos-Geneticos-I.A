import numpy as np
import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
from scipy.optimize import minimize

# Definindo a função objetivo
def objective(x):
    x1, x2 = x
    return 100 * (x1**2 - x2)**2 + (1 - x1)**2

# Restrições não lineares
def constraint1(x):
    x1, x2 = x
    return -(x1 * x2 + x1 - x2 + 1.5)  # Deve ser <= 0

def constraint2(x):
    x1, x2 = x
    return -(10 - x1 - x2)  # Deve ser <= 0

# Definição das restrições para o otimizador
constraints = [
    {'type': 'ineq', 'fun': constraint1},
    {'type': 'ineq', 'fun': constraint2}
]

# Limites das variáveis
bounds = [(0, 1), (0, 3)]

# Estimativa inicial
x0 = [0.5, 0.5]

# Otimização
result = minimize(objective, x0, bounds=bounds, constraints=constraints)

# Geração da malha para o gráfico 3D
x1_vals = np.linspace(0, 1, 100)
x2_vals = np.linspace(0, 3, 100)
X1, X2 = np.meshgrid(x1_vals, x2_vals)
Z = 100 * (X1**2 - X2)**2 + (1 - X1)**2

# Plotando o gráfico 3D com mesh
fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.8, edgecolor='k')
ax.set_xlabel('x1')
ax.set_ylabel('x2')
ax.set_zlabel('f(x)')

# Marcando o ponto ótimo
x_opt, y_opt = result.x
z_opt = objective(result.x)
ax.scatter(x_opt, y_opt, z_opt, color='red', s=50, label='Mínimo encontrado')
ax.legend()

plt.title('Otimização com Restrições - Questão 5')
plt.savefig("questao5_grafico.png")
# plt.show()