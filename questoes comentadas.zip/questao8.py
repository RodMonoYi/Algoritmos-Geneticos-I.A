import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D # Corrigido para Axes3D

# 1. Definindo a função Lucro (original)
def lucro_function(xy_array):
    x, y = xy_array
    return 60*x + 100*y - (3/2)*x**2 - (3/2)*y**2 - x*y

# Definindo a função lucro negativa (para encontrar o máximo através da minimização)
def neg_lucro_function(xy_array):
    return -lucro_function(xy_array)

# 2. Definindo os limites das variáveis (restrições de não negatividade)
# x >= 0, y >= 0. Não há limites superiores explícitos.
bounds = [(0, None), (0, None)]

# 3. Estimativa inicial para o otimizador
# Um ponto razoável para começar a busca.
x0 = [10.0, 10.0] # Por exemplo, 10 unidades de cada

# 4. Otimização para o Máximo (minimizando a função lucro negativa)
print("--- Otimização para MAXIMIZAR o Lucro (Questão 8) ---")
# Usamos 'L-BFGS-B' que é bom para otimização com limites (bounds)
result_max_lucro = minimize(neg_lucro_function, x0, method='L-BFGS-B', bounds=bounds, options={'disp': True})

# 5. Extraindo e exibindo os resultados
if result_max_lucro.success:
    x_opt, y_opt = result_max_lucro.x
    max_lucro = -result_max_lucro.fun # Inverte o sinal para obter o lucro máximo
    print(f"\n--- Resultados da Otimização de Lucro ---")
    print(f"Produção que maximiza o lucro:")
    print(f"  Produto A (x): {x_opt:.2f} unidades")
    print(f"  Produto B (y): {y_opt:.2f} unidades")
    print(f"Lucro máximo esperado: {max_lucro:.2f}")
else:
    print(f"\nNão foi possível encontrar a produção que maximiza o lucro.")
    print(f"Status da otimização: {result_max_lucro.message}")

# --- Visualização (Mesh) ---

# Geração da malha para o gráfico 3D
# Vamos definir um range de plotagem que inclua a solução ótima e um pouco além.
# Os valores ótimos esperados para x e y não serão excessivamente grandes.
# Um range de 0 a 50 deve ser suficiente para visualizar a parábola invertida.
x_vals_plot = np.linspace(0, 50, 100)
y_vals_plot = np.linspace(0, 50, 100)
X, Y = np.meshgrid(x_vals_plot, y_vals_plot)

# Calculando os valores da função Lucro para cada ponto da malha
Z = lucro_function([X, Y])

# Plotando o gráfico 3D com mesh
fig = plt.figure(figsize=(12, 9))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície do lucro
# 'cmap' pode ser 'viridis', 'plasma', 'coolwarm', 'magma', etc.
surface = ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8, rstride=5, cstride=5)
fig.colorbar(surface, shrink=0.5, aspect=5, label='Lucro L(x, y)')

# Marcar o ponto de lucro máximo
if result_max_lucro.success:
    ax.scatter(x_opt, y_opt, max_lucro, color='red', s=200, marker='o',
               label=f'Lucro Máximo: (x={x_opt:.0f}, y={y_opt:.0f}, L={max_lucro:.0f})')

ax.set_xlabel('Unidades do Produto A (x)')
ax.set_ylabel('Unidades do Produto B (y)')
ax.set_zlabel('Lucro L(x, y)')
ax.set_title('Superfície de Lucro da Indústria')

ax.view_init(elev=30, azim=45) # Ajustar o ângulo de visão
ax.legend()
plt.tight_layout()
# plt.show()
plt.savefig('questao8_grafico.png') # Para salvar o gráfico como imagem