import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import differential_evolution

# 1. Definindo a função objetivo (negativo de g(x) para encontrar o máximo)
def objective_function(x_array):
    # x_array é um array numpy, mesmo que seja apenas um elemento
    x = x_array[0] # Extrai o valor de x

    # A função original g(x)
    g_x = (2**(-2 * ((x - 0.1) / 0.9)**2)) * (np.sin(5 * np.pi * x)**6)

    # Retornamos o negativo de g(x) porque differential_evolution MINIMIZA
    return -g_x

# 2. Definindo os limites para x
# bounds deve ser uma lista de tuplas, onde cada tupla é (min, max) para cada variável
bounds = [(0, 1)] # xmin = 0, xmax = 1

# 3. Executando o algoritmo de otimização global (Differential Evolution como análogo ao GA)
# 'popsize' e 'maxiter' são parâmetros que você pode ajustar para melhor desempenho.
# 'disp=True' para ver o progresso da otimização
result = differential_evolution(objective_function, bounds, disp=True, strategy='best1bin', maxiter=1000, popsize=15)

# 4. Extraindo os resultados
x_otimo = result.x[0] # O valor de x que otimiza a função
min_neg_g_x = result.fun # O valor mínimo da função negativa (ou seja, -g(x_otimo))

# O valor máximo da função g(x) original é o negativo do valor mínimo encontrado
max_g_x = -min_neg_g_x

# 5. Exibindo os resultados
print(f"\n--- Resultados da Otimização (Questão 1) ---")
print(f"O valor de x que maximiza a função é: {x_otimo:.6f}")
print(f"O valor máximo da função g(x) é: {max_g_x:.6f}")

# 6. Opcional: Plotar a função para visualizar o máximo
x_vals = np.linspace(0, 1, 1000)
g_vals = (2**(-2 * ((x_vals - 0.1) / 0.9)**2)) * (np.sin(5 * np.pi * x_vals)**6)

plt.figure(figsize=(10, 6))
plt.plot(x_vals, g_vals, label='$g(x) = 2^{-2((x-0.1)/0.9)^2} \sin(5\pi x)^6$')
plt.plot(x_otimo, max_g_x, 'ro', markersize=8, label=f'Máximo Encontrado ($x={x_otimo:.4f}$, $g(x)={max_g_x:.4f}$)')

plt.title('Maximização da Função g(x) usando Differential Evolution')
plt.xlabel('x')
plt.ylabel('g(x)')
plt.grid(True)
plt.legend()
plt.ylim(bottom=0) # Garante que o eixo Y comece em 0 ou um pouco abaixo
# plt.show() # Você precisará do servidor X configurado ou mude para plt.savefig()
plt.savefig('questao1_grafico.png') # Se não quiser configurar o servidor X