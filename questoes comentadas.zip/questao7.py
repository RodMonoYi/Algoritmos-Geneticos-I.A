import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

# 1. Definindo a função objetivo
def f(x_array):
    # x_array é um array, mesmo para uma única variável
    x = x_array[0]
    return x**2 - 3*x + 4

# 2. Definindo os limites da variável
# bounds para uma única variável é uma lista de uma tupla
bounds = [(-10, 10)] # xmin = -10, xmax = 10

# 3. Estimativa inicial para o otimizador
# Um ponto qualquer dentro dos limites
x0 = [0.0] # Começamos no zero, por exemplo

# 4. Otimização para o Mínimo
print("--- Otimização para o MÍNIMO (Questão 7) ---")
# method='L-BFGS-B' é uma boa escolha para otimização com limites (bounds)
# 'disp=True' para ver o progresso
result_min = minimize(f, x0, method='L-BFGS-B', bounds=bounds, options={'disp': True})

# 5. Extraindo e exibindo os resultados
if result_min.success:
    x_min_found = result_min.x[0]
    f_min_found = result_min.fun
    print(f"\nO valor de x que MINIMIZA a função é: {x_min_found:.6f}")
    print(f"O valor MÍNIMO da função f(x) é: {f_min_found:.6f}")
else:
    print(f"\nNão foi possível encontrar o MÍNIMO da função.")
    print(f"Status da otimização: {result_min.message}")

# --- Opcional: Plotar a função para visualizar o mínimo ---
x_vals = np.linspace(-10, 10, 400) # Mais pontos para uma curva suave
f_vals = f([x_vals]) # Passa como array para a função f

plt.figure(figsize=(10, 6))
plt.plot(x_vals, f_vals, label='$f(x) = x^2 - 3x + 4$')
plt.scatter(x_min_found, f_min_found, color='red', s=100, marker='o',
            label=f'Mínimo Encontrado ($x={x_min_found:.2f}$, $f(x)={f_min_found:.2f}$)')

plt.title('Minimização da Função $f(x) = x^2 - 3x + 4$')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.grid(True)
plt.legend()
# plt.show()
plt.savefig('questao7_grafico.png') # Para salvar o gráfico como imagem