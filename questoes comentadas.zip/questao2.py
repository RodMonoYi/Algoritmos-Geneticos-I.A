import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D # Importa a ferramenta 3D

# 1. Definindo a função objetivo
def f(x1, x2):
    return (x1**2 + x2**2 - 1)**2

# 2. Definindo os limites das variáveis
x1_min, x1_max = -1, 1
x2_min, x2_max = -1, 1

# 3. Geração da malha para o gráfico 3D
# Usaremos 100 pontos em cada dimensão para uma superfície suave
num_points = 50
x1_vals = np.linspace(x1_min, x1_max, num_points)
x2_vals = np.linspace(x2_min, x2_max, num_points)
X1, X2 = np.meshgrid(x1_vals, x2_vals)

# Calculando os valores da função f(x1, x2) para cada ponto da malha
Z = f(X1, X2)

# 4. Encontrando os pontos de mínimo e máximo analiticamente (ou por observação)

# Pontos de Mínimo: Onde x1^2 + x2^2 = 1 (o círculo unitário)
# No gráfico, esses pontos formam um "vale" circular com valor Z = 0.
# Podemos escolher um ponto representativo para marcação, como (0, 1) ou (1, 0),
# ou simplesmente observar que o mínimo é 0 em todo o círculo unitário.
# Para fins de marcação, vamos apenas indicar o valor mínimo.
min_f_val = 0.0
# Pontos onde o mínimo ocorre (ex: (0,1), (1,0), (0,-1), (-1,0) e todos os pontos intermediários no círculo)
# Como não há um único ponto de mínimo, não marcaremos um único ponto 'ro'.
# Em vez disso, destacaremos o vale no gráfico.

# Pontos de Máximo: Nos cantos do quadrado
max_points = [
    (-1, -1),
    (-1, 1),
    (1, -1),
    (1, 1)
]
max_f_val = f(max_points[0][0], max_points[0][1]) # O valor será o mesmo para todos

# 5. Exibindo os resultados
print(f"--- Resultados da Análise (Questão 2) ---")
print(f"Valor Mínimo da função: {min_f_val:.4f}")
print(f"Ocorre em qualquer ponto (x1, x2) onde x1^2 + x2^2 = 1, dentro da região definida.")
print(f"Valor Máximo da função: {max_f_val:.4f}")
print(f"Ocorre nos pontos: {max_points}")

# 6. Plotando o gráfico 3D com mesh
fig = plt.figure(figsize=(12, 9))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície
# cmap='viridis' ou 'plasma' ou 'coolwarm' são boas escolhas para cores
surface = ax.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.8, rstride=1, cstride=1)

# Adicionar uma barra de cores para a escala de Z
fig.colorbar(surface, shrink=0.5, aspect=5, label='f(x1, x2) - Valor da Função')

# Marcar os pontos de máximo
for p in max_points:
    ax.scatter(p[0], p[1], f(p[0], p[1]), color='red', s=100, marker='o', label='Máximo Encontrado' if p == max_points[0] else "")

# Adicionar uma linha para o vale dos mínimos (o círculo unitário)
theta = np.linspace(0, 2*np.pi, 100)
circle_x1 = np.cos(theta)
circle_x2 = np.sin(theta)
# Garante que os pontos do círculo estejam dentro dos limites de x1 e x2 (-1 a 1)
mask = (circle_x1 >= x1_min) & (circle_x1 <= x1_max) & \
       (circle_x2 >= x2_min) & (circle_x2 <= x2_max)
ax.plot(circle_x1[mask], circle_x2[mask], np.zeros_like(circle_x1[mask]), 'b--', linewidth=2, label='Localização dos Mínimos (Z=0)')


ax.set_xlabel('$x_1$')
ax.set_ylabel('$x_2$')
ax.set_zlabel('$f(x_1, x_2)$')
ax.set_title('Superfície da Função $f(x_1, x_2) = (x_1^2 + x_2^2 - 1)^2$')

# Configurações de visualização para melhor clareza
ax.view_init(elev=30, azim=45) # Ajusta o ângulo de visão

plt.legend()
plt.tight_layout() # Ajusta o layout para evitar sobreposição
# plt.show()
plt.savefig('questao2_grafico.png') # Se não quiser configurar o servidor X