import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D # Corrigido para Axes3D

# 1. Definindo a função objetivo
def f(x_array):
    x1, x2 = x_array
    return (x1**2 + x2**2 - 1)**2

# Definindo a função objetivo negativa (para encontrar o máximo)
def neg_f(x_array):
    return -f(x_array)

# 2. Definindo as restrições não lineares
# Todas as restrições devem ser da forma g(x) >= 0 para 'ineq'
def constraint1(x): # x1 + x2 >= 1  => x1 + x2 - 1 >= 0
    return x[0] + x[1] - 1

def constraint2(x): # x1 * x2 >= 1/2 => x1 * x2 - 0.5 >= 0
    return x[0] * x[1] - 0.5

def constraint3(x): # x2 >= x1^2   => x2 - x1^2 >= 0
    return x[1] - x[0]**2

def constraint4(x): # x1 >= x2^2   => x1 - x2^2 >= 0
    return x[0] - x[1]**2

# Lista de restrições para o otimizador
constraints = [
    {'type': 'ineq', 'fun': constraint1},
    {'type': 'ineq', 'fun': constraint2},
    {'type': 'ineq', 'fun': constraint3},
    {'type': 'ineq', 'fun': constraint4}
]

# 3. Definindo os limites das variáveis
bounds = [(-1, 1), (-1, 1)] # -1 <= x1 <= 1, -1 <= x2 <= 1

# Estimativa inicial para o otimizador
# Um ponto dentro dos limites e, se possível, que satisfaça algumas restrições.
# O ponto (1,1) sabemos que é viável.
x0 = [1.0, 1.0]

# 4. Otimização para Mínimo
print("--- Otimização para o MÍNIMO ---")
result_min = minimize(f, x0, method='SLSQP', bounds=bounds, constraints=constraints, options={'disp': True})

# 5. Otimização para Máximo (minimizando -f(x))
print("\n--- Otimização para o MÁXIMO ---")
result_max = minimize(neg_f, x0, method='SLSQP', bounds=bounds, constraints=constraints, options={'disp': True})

# 6. Exibindo os resultados
print("\n--- Resultados da Otimização (Questão 6) ---")

if result_min.success:
    x_min = result_min.x
    f_min = result_min.fun
    print(f"Mínimo Encontrado:")
    print(f"  x1={x_min[0]:.6f}, x2={x_min[1]:.6f}")
    print(f"  Valor Mínimo de f(x) = {f_min:.6f}")
else:
    print(f"Não foi possível encontrar o MÍNIMO da função.")
    print(f"Status da otimização para o mínimo: {result_min.message}")

if result_max.success:
    x_max = result_max.x
    f_max = -result_max.fun # Inverte o sinal para obter o valor máximo da função original
    print(f"\nMáximo Encontrado:")
    print(f"  x1={x_max[0]:.6f}, x2={x_max[1]:.6f}")
    print(f"  Valor Máximo de f(x) = {f_max:.6f}")
else:
    print(f"\nNão foi possível encontrar o MÁXIMO da função.")
    print(f"Status da otimização para o máximo: {result_max.message}")


# --- Visualização (Mesh) ---

# Geração da malha para o gráfico 3D dentro dos limites
x1_vals_plot = np.linspace(bounds[0][0], bounds[0][1], 100)
x2_vals_plot = np.linspace(bounds[1][0], bounds[1][1], 100)
X1, X2 = np.meshgrid(x1_vals_plot, x2_vals_plot)
Z = f([X1, X2])

fig = plt.figure(figsize=(12, 9))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície da função
surface = ax.plot_surface(X1, X2, Z, cmap='coolwarm', alpha=0.8)
fig.colorbar(surface, shrink=0.5, aspect=5, label='f(x1, x2)')

ax.set_xlabel('$x_1$')
ax.set_ylabel('$x_2$')
ax.set_zlabel('$f(x_1, x_2)$')
ax.set_title('Superfície da Função $f(x_1, x_2)$ com Restrições (Questão 6)')

# Marcar os pontos encontrados APENAS se a otimização foi bem-sucedida
if result_min.success:
    ax.scatter(x_min[0], x_min[1], f_min, color='green', s=150, marker='o', label=f'Mínimo Ot. ({x_min[0]:.2f}, {x_min[1]:.2f}, {f_min:.2f})')
if result_max.success:
    ax.scatter(x_max[0], x_max[1], f_max, color='red', s=150, marker='s', label=f'Máximo Ot. ({x_max[0]:.2f}, {x_max[1]:.2f}, {f_max:.2f})')

# Opcional: Visualizar as bordas das restrições no plano Z=0 para ajudar a entender a região viável
# Para visualizar as restrições não lineares:
# x1 + x2 = 1
ax.plot(x1_vals_plot, 1 - x1_vals_plot, np.zeros_like(x1_vals_plot), 'k--', linewidth=1, label='$x_1+x_2=1$')

# x1 * x2 = 0.5 (uma hipérbole)
# Gerar pontos para a curva x2 = 0.5 / x1 para plotar
x1_curve = np.linspace(0.1, 1.0, 100) # Evita divisão por zero
x2_curve = 0.5 / x1_curve
# Filtrar pontos dentro dos limites e que satisfaçam outras restrições se possível (para um plot mais limpo)
mask_curve = (x1_curve >= bounds[0][0]) & (x1_curve <= bounds[0][1]) & \
             (x2_curve >= bounds[1][0]) & (x2_curve <= bounds[1][1])
ax.plot(x1_curve[mask_curve], x2_curve[mask_curve], np.zeros_like(x1_curve[mask_curve]), 'm--', linewidth=1, label='$x_1x_2=0.5$')

# x2 = x1^2 (uma parábola)
ax.plot(x1_vals_plot, x1_vals_plot**2, np.zeros_like(x1_vals_plot), 'c--', linewidth=1, label='$x_2=x_1^2$')

# x1 = x2^2 (outra parábola)
ax.plot(x2_vals_plot**2, x2_vals_plot, np.zeros_like(x2_vals_plot), 'y--', linewidth=1, label='$x_1=x_2^2$')


ax.view_init(elev=30, azim=45)
ax.legend()
plt.tight_layout()
# plt.show()
plt.savefig('questao6_grafico.png') # Se não quiser configurar o servidor X