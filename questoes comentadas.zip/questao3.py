import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D # Corrigido para Axes3D

# 1. Definindo a função objetivo original
def f(x_array):
    x1, x2 = x_array
    return 0.5 * x1**2 + x2**2 - x1*x2 - 2*x1 - 6*x2

# Definindo a função objetivo negativa (para encontrar o máximo)
def neg_f(x_array):
    return -f(x_array)

# 2. Definindo as restrições lineares de desigualdade
# Todas as restrições devem ser da forma g(x) >= 0
constraints = [
    # g1: x1 + x2 <= 2  => 2 - x1 - x2 >= 0
    {'type': 'ineq', 'fun': lambda x: 2 - x[0] - x[1]},
    # g2: -x1 + x2 <= 2 => 2 + x[0] - x[1] >= 0
    {'type': 'ineq', 'fun': lambda x: 2 + x[0] - x[1]},
    # g3: 2x1 + 2x2 <= 3 => 3 - 2*x[0] - 2*x[1] >= 0
    {'type': 'ineq', 'fun': lambda x: 3 - 2*x[0] - 2*x[1]}
]

# 3. Definindo os limites das variáveis
# x1 >= 0, x2 >= 0. Não há limites superiores explícitos além das restrições.
# As restrições já implicam que x1 e x2 não podem ser muito grandes.
# Por exemplo, x1 <= 2 (da 1ª restrição), x2 <= 2 (da 2ª restrição).
# Para o plot, vamos usar um range razoável para a malha.
bounds = [(0, None), (0, None)] # x1 >= 0, x2 >= 0

# Estimativa inicial para o otimizador
x0 = [0.5, 0.5] # Um ponto dentro da região permitida

# 4. Otimização para Mínimo
print("--- Otimização para o MÍNIMO ---")
result_min = minimize(f, x0, method='SLSQP', bounds=bounds, constraints=constraints)
x_min = result_min.x
f_min = result_min.fun
print(f"O valor de x1 e x2 que MINIMIZA a função é: x1={x_min[0]:.4f}, x2={x_min[1]:.4f}")
print(f"O valor MÍNIMO da função f(x) é: {f_min:.4f}\n")

# 5. Otimização para Máximo (minimizando -f(x))
print("--- Otimização para o MÁXIMO ---")
result_max = minimize(neg_f, x0, method='SLSQP', bounds=bounds, constraints=constraints)
x_max = result_max.x
f_max = -result_max.fun # Inverte o sinal para obter o valor máximo da função original
print(f"O valor de x1 e x2 que MAXIMIZA a função é: x1={x_max[0]:.4f}, x2={x_max[1]:.4f}")
print(f"O valor MÁXIMO da função f(x) é: {f_max:.4f}\n")

# --- Visualização (Mesh) ---

# Geração da malha para o gráfico 3D
# Determine um range de plotagem que cubra a área das soluções e restrições
# As restrições implicam que x1 e x2 não excederão 2 (ou 1.5/2 = 0.75 da 3ª)
x1_vals = np.linspace(-0.5, 2.5, 100) # Um pouco além dos limites para ver a forma da função
x2_vals = np.linspace(-0.5, 2.5, 100)
X1, X2 = np.meshgrid(x1_vals, x2_vals)
Z = f([X1, X2]) # Calculando os valores da função f(x1, x2) para a malha

# Plotando o gráfico 3D com mesh
fig = plt.figure(figsize=(12, 9))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície
surface = ax.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.7, rstride=5, cstride=5)
fig.colorbar(surface, shrink=0.5, aspect=5, label='f(x1, x2)')

# Marcar o ponto de mínimo
ax.scatter(x_min[0], x_min[1], f_min, color='red', s=150, marker='o', label=f'Mínimo: ({x_min[0]:.2f}, {x_min[1]:.2f}, {f_min:.2f})')

# Marcar o ponto de máximo
ax.scatter(x_max[0], x_max[1], f_max, color='blue', s=150, marker='s', label=f'Máximo: ({x_max[0]:.2f}, {x_max[1]:.2f}, {f_max:.2f})')

# Desenhar as restrições no plano Z=0 para visualizar a região viável
# x1 + x2 <= 2  => x2 = 2 - x1
ax.plot(x1_vals, 2 - x1_vals, 0, color='gray', linestyle='--', label='$x_1 + x_2 = 2$')
# -x1 + x2 <= 2 => x2 = 2 + x1
ax.plot(x1_vals, 2 + x1_vals, 0, color='gray', linestyle='--', label='$-x_1 + x_2 = 2$')
# 2x1 + 2x2 <= 3 => x2 = (3 - 2x1) / 2
ax.plot(x1_vals, (3 - 2*x1_vals) / 2, 0, color='gray', linestyle='--', label='$2x_1 + 2x_2 = 3$')

# Adicionar linhas para os limites x1 >= 0 e x2 >= 0
ax.plot([0, 0], [x2_vals.min(), x2_vals.max()], 0, color='gray', linestyle='--', label='$x_1 = 0$')
ax.plot([x1_vals.min(), x1_vals.max()], [0, 0], 0, color='gray', linestyle='--', label='$x_2 = 0$')

ax.set_xlabel('$x_1$')
ax.set_ylabel('$x_2$')
ax.set_zlabel('$f(x_1, x_2)$')
ax.set_title('Otimização da Função $f(x_1, x_2)$ com Restrições')
ax.view_init(elev=30, azim=-45) # Ajustar o ângulo de visão
ax.legend()
plt.tight_layout()
# plt.show()
plt.savefig('questao3_grafico.png') # Se não quiser configurar o servidor X