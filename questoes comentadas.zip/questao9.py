import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D # Corrigido para Axes3D

# 1. Definindo a função objetivo (Área da Superfície, após substituição de z)
# A(x, y) = xy + 8/y + 8/x
def area_function(xy_array):
    x, y = xy_array
    # Para evitar divisão por zero ou resultados infinitos/NaNs para o otimizador
    # em casos extremos de valores muito próximos de zero, podemos adicionar um pequeno epsilon.
    # No entanto, os bounds já cuidam de manter x,y > 0.
    return x*y + 8/y + 8/x

# 2. Definindo os limites das variáveis
# x > 0, y > 0. Podemos usar um limite inferior muito pequeno, ou None para superior.
# Para evitar problemas numéricos próximos de zero, usaremos um pequeno epsilon.
epsilon = 1e-6
bounds = [(epsilon, None), (epsilon, None)] # x >= epsilon, y >= epsilon

# 3. Estimativa inicial para o otimizador
# Um ponto razoável para começar a busca (V=4, então x=y=2, z=1 daria V=4)
x0 = [2.0, 2.0]

# 4. Otimização para o MÍNIMO da Área
print("--- Otimização para MINIMIZAR a Área da Superfície (Questão 9) ---")
# Usamos 'L-BFGS-B' que é bom para otimização com limites (bounds)
result_min_area = minimize(area_function, x0, method='L-BFGS-B', bounds=bounds, options={'disp': True})

# 5. Extraindo e exibindo os resultados
if result_min_area.success:
    x_opt, y_opt = result_min_area.x
    
    # Calcular z_opt a partir da restrição de volume
    volume_fixo = 4
    z_opt = volume_fixo / (x_opt * y_opt)

    min_area = result_min_area.fun
    
    print(f"\n--- Resultados da Otimização da Caixa ---")
    print(f"Dimensões que minimizam a área:")
    print(f"  x (comprimento): {x_opt:.4f} m")
    print(f"  y (largura):     {y_opt:.4f} m")
    print(f"  z (altura):      {z_opt:.4f} m")
    print(f"Área mínima da superfície: {min_area:.4f} m²")
    print(f"Volume verificado: {x_opt * y_opt * z_opt:.4f} m³ (deve ser aproximadamente 4)")
else:
    print(f"\nNão foi possível encontrar as dimensões que minimizam a área.")
    print(f"Status da otimização: {result_min_area.message}")

# --- Visualização (Mesh) ---
# Vamos plotar a função da área A(x,y) dentro de um domínio razoável

# Definir um range de plotagem que inclua a solução ótima.
# x e y provavelmente estarão ao redor de 2, como no caso de um cubo (onde x=y=z).
x_vals_plot = np.linspace(0.5, 4.0, 50)
y_vals_plot = np.linspace(0.5, 4.0, 50)
X_plot, Y_plot = np.meshgrid(x_vals_plot, y_vals_plot)

# Calcular os valores da função da área A(x, y) para a malha
# Cuidado com divisão por zero se os eixos X_plot ou Y_plot incluírem 0.
# O otimizador já lida com epsilon, mas para o plot precisamos garantir.
Z_area = np.zeros_like(X_plot)
for i in range(X_plot.shape[0]):
    for j in range(X_plot.shape[1]):
        current_x = X_plot[i, j]
        current_y = Y_plot[i, j]
        if current_x > epsilon and current_y > epsilon:
            Z_area[i, j] = area_function([current_x, current_y])
        else:
            Z_area[i, j] = np.inf # Ou um valor grande para mostrar que é proibido

fig = plt.figure(figsize=(12, 9))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície da área
# Use cmap='viridis' ou 'jet' para representar os valores de área
surface = ax.plot_surface(X_plot, Y_plot, Z_area, cmap='jet', alpha=0.8, rstride=1, cstride=1)
fig.colorbar(surface, shrink=0.5, aspect=5, label='Área da Superfície A(x, y) m²')

# Marcar o ponto de área mínima
if result_min_area.success:
    ax.scatter(x_opt, y_opt, min_area, color='red', s=200, marker='o',
               label=f'Área Mínima: ({x_opt:.2f}, {y_opt:.2f}, {min_area:.2f})')

ax.set_xlabel('Comprimento (x) m')
ax.set_ylabel('Largura (y) m')
ax.set_zlabel('Área da Superfície (A) m²')
ax.set_title('Área da Superfície da Caixa Retangular sem Tampa')

ax.view_init(elev=30, azim=45) # Ajustar o ângulo de visão
ax.legend()
plt.tight_layout()
# plt.show()
plt.savefig('questao9_grafico.png') # Para salvar o gráfico como imagem