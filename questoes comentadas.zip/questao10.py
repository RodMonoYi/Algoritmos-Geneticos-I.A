import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog
from mpl_toolkits.mplot3d import Axes3D # Corrigido para Axes3D

# 1. Definindo a função Lucro para plotagem 3D (apenas para visualização)
def lucro_surface(x1, x2):
    return 4*x1 + x2

# --- PARTE 1: Otimização original ---
print("--- Parte 1: Otimização de Lucro Original ---")

# Coeficientes da função objetivo (para linprog, é para MINIMIZAR c.T @ x)
# Portanto, para maximizar 4*x1 + x2, minimizamos -4*x1 - x2
c = [-4, -1] # Coeficientes do lucro negativo

# Coeficientes das restrições de desigualdade (A_ub @ x <= b_ub)
# 9*x1 + x2 <= 18
# 3*x1 + x2 <= 12
A_ub = [
    [9, 1],
    [3, 1]
]
b_ub = [18, 12] # Limites dos recursos

# Limites das variáveis (não negatividade)
# x1 >= 0, x2 >= 0
x1_bounds = (0, None)
x2_bounds = (0, None)
bounds = [x1_bounds, x2_bounds]

# Executa a otimização linear
result_original = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')

# Extraindo e exibindo os resultados originais
if result_original.success:
    x1_orig, x2_orig = result_original.x
    lucro_orig = lucro_surface(x1_orig, x2_orig) # Calcula o lucro com a função original
    print(f"\n--- Resultado Original ---")
    print(f"Produção ideal (Produto 1): {x1_orig:.2f} unidades")
    print(f"Produção ideal (Produto 2): {x2_orig:.2f} unidades")
    print(f"Lucro máximo (original): ${lucro_orig:.2f}")
    # Verificar restrições para debug
    # print(f"Horas-homem utilizadas: {9*x1_orig + x2_orig:.2f} <= {b_ub[0]}")
    # print(f"Horas-máquina utilizadas: {3*x1_orig + x2_orig:.2f} <= {b_ub[1]}")
else:
    print(f"\nNão foi possível encontrar a solução para a otimização original.")
    print(f"Status: {result_original.message}")

# --- PARTE 2: Impacto com horas-homem limitadas a 15 ---
print("\n--- Parte 2: Impacto com Horas-Homem = 15 ---")

# Atualiza o limite de horas-homem na restrição
b_ub_new = [15, 12] # Apenas o primeiro elemento muda

# Executa a otimização linear com o novo limite
result_impacto = linprog(c, A_ub=A_ub, b_ub=b_ub_new, bounds=bounds, method='highs')

# Extraindo e exibindo os resultados do impacto
if result_impacto.success:
    x1_imp, x2_imp = result_impacto.x
    lucro_imp = lucro_surface(x1_imp, x2_imp)
    print(f"\n--- Resultado com Horas-Homem = 15 ---")
    print(f"Produção ideal (Produto 1): {x1_imp:.2f} unidades")
    print(f"Produção ideal (Produto 2): {x2_imp:.2f} unidades")
    print(f"Lucro máximo (impacto): ${lucro_imp:.2f}")
    print(f"\nImpacto no lucro: ${lucro_orig - lucro_imp:.2f} (redução)")
    # print(f"Horas-homem utilizadas: {9*x1_imp + x2_imp:.2f} <= {b_ub_new[0]}")
    # print(f"Horas-máquina utilizadas: {3*x1_imp + x2_imp:.2f} <= {b_ub_new[1]}")
else:
    print(f"\nNão foi possível encontrar a solução para a otimização com impacto.")
    print(f"Status: {result_impacto.message}")


# --- Visualização (Função "Mesh") ---

# Vamos plotar a superfície da função lucro e as restrições para visualizar a região viável
# O domínio da função para plotagem precisa ser ajustado para ser visível
x1_plot_max = max(x1_orig, x1_imp) + 2 # Ajusta o limite superior de plotagem
x2_plot_max = max(x2_orig, x2_imp) + 2 # Ajusta o limite superior de plotagem

x1_vals_plot = np.linspace(0, x1_plot_max, 50)
x2_vals_plot = np.linspace(0, x2_plot_max, 50)
X1_mesh, X2_mesh = np.meshgrid(x1_vals_plot, x2_vals_plot)
Z_lucro = lucro_surface(X1_mesh, X2_mesh)

fig = plt.figure(figsize=(14, 10))
ax = fig.add_subplot(111, projection='3d')

# Plotar a superfície do lucro (é um plano em programação linear)
surface = ax.plot_surface(X1_mesh, X2_mesh, Z_lucro, cmap='viridis', alpha=0.7)
fig.colorbar(surface, shrink=0.5, aspect=5, label='Lucro')

# Marcar os pontos ótimos
if result_original.success:
    ax.scatter(x1_orig, x2_orig, lucro_surface(x1_orig, x2_orig), color='red', s=200, marker='o',
               label=f'Ótimo Original (Lucro: ${lucro_orig:.2f})')
if result_impacto.success:
    ax.scatter(x1_imp, x2_imp, lucro_surface(x1_imp, x2_imp), color='blue', s=200, marker='s',
               label=f'Ótimo Impacto (Lucro: ${lucro_imp:.2f})')

# Plotar as linhas das restrições no plano Z=0 para visualizar a região viável
# Restrição 1: 9x1 + x2 = 18 => x2 = 18 - 9x1
x1_line1 = np.linspace(0, x1_plot_max, 100)
x2_line1_orig = 18 - 9*x1_line1
x2_line1_imp = 15 - 9*x1_line1

# Restrição 2: 3x1 + x2 = 12 => x2 = 12 - 3x1
x2_line2 = 12 - 3*x1_line1

# Filtrar pontos para plotar apenas dentro dos limites do gráfico
mask_line1_orig = (x2_line1_orig >= 0) & (x2_line1_orig <= x2_plot_max)
mask_line1_imp = (x2_line1_imp >= 0) & (x2_line1_imp <= x2_plot_max)
mask_line2 = (x2_line2 >= 0) & (x2_line2 <= x2_plot_max)


ax.plot(x1_line1[mask_line1_orig], x2_line1_orig[mask_line1_orig], 0, 'k--', linewidth=1, label='$9x_1 + x_2 = 18$ (original)')
ax.plot(x1_line1[mask_line1_imp], x2_line1_imp[mask_line1_imp], 0, 'g--', linewidth=1, label='$9x_1 + x_2 = 15$ (impacto)')
ax.plot(x1_line1[mask_line2], x2_line2[mask_line2], 0, 'purple', linestyle='--', linewidth=1, label='$3x_1 + x_2 = 12$')

# Adicionar linhas de não negatividade
ax.plot([0, 0], [0, x2_plot_max], 0, 'k-', linewidth=1, label='$x_1 = 0$')
ax.plot([0, x1_plot_max], [0, 0], 0, 'k-', linewidth=1, label='$x_2 = 0$')

ax.set_xlabel('Produto 1 (x1)')
ax.set_ylabel('Produto 2 (x2)')
ax.set_zlabel('Lucro')
ax.set_title('Maximização do Lucro com Restrições de Produção')
ax.view_init(elev=30, azim=-60) # Ajustar o ângulo de visão
ax.legend()
plt.tight_layout()
# plt.show()
plt.savefig('questao10_grafico.png') # Para salvar o gráfico como imagem